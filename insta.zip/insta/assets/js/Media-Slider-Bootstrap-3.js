$(document).ready(function() {
    $('#Carousel').carousel({
        interval: 5000
    })
});