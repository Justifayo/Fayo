$(document).ready(function(){
  new WOW().init();
});